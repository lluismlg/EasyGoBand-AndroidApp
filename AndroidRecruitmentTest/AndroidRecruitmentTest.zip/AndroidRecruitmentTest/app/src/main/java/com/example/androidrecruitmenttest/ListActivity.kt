package com.example.androidrecruitmenttest

import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.GsonBuilder
import okhttp3.*
import java.io.IOException


class ListActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        recyclerView_list.setBackgroundColor(Color.BLUE)

        fetchJson()

        // Edit actionbar
        val listActionbar = supportActionBar
        listActionbar!!.title = "Events List"
        //set back button
        listActionbar.setDisplayHomeAsUpEnabled(true)
        listActionbar.setDisplayHomeAsUpEnabled(true)

        // Get the Intent that started this activity and extract the string
        val message = intent.getStringExtra(EXTRA_MESSAGE)

        val textViewID = findViewById<TextView>(R.id.ListTextView).apply {
            text = message
        }
    }

    private fun fetchJson() {

        val url = "https://pnny0h3cuf.execute-api.eu-west-1.amazonaws.com/dev/providers/1"

        val client = OkHttpClient()

        val authValue = "Basic cJmAc71jah17sgqi1jqaksvaksda="

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", authValue)
            .build()


        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                val body = response.body()?.string()
                println(body)

                val gson = GsonBuilder().create()

                val TicketFeed: Array<Ticket> = gson.fromJson(body, Array<Ticket>::class.java)

            };

            override fun onFailure(call: Call, e: IOException) {}
        })
    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}

class Ticket(
    val access_group_id: Int,
    val access_group_name: String,
    val basic_product_id: Int,
    val event_id: Int,
    val id: Int,
    val modified: String,
    val name: String,
    val sessions: List<Session>,
    val structure_decode: Boolean,
    val total_uses: Int
)

class Session(
    val id: Int,
    val name: String
)

